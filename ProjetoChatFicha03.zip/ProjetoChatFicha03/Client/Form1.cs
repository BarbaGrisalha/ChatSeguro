﻿using EI.SI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Client
{
   
    public partial class Form1 : Form
    {
        private const int PORT = 500; //DEFINIMOS O PORTO PARA UTILIZAR
        NetworkStream networkStream;
        TcpClient tcpClient;
        ProtocolSI protocolSI;

        public Form1()
        {
            InitializeComponent();
            IPEndPoint endPoint = new IPEndPoint(IPAddress.Loopback, PORT);
            tcpClient = new TcpClient();
            tcpClient.Connect(endPoint);
            networkStream = tcpClient.GetStream();
            protocolSI = new ProtocolSI();
        }

        private void buttonSend_Click(object sender, EventArgs e)
        {
            string msg = textBox1_Message.Text;
            textBox1_Message.Clear();
            byte[] packet = protocolSI.Make(ProtocolSICmdType.DATA, msg);
            networkStream.Write(packet, 0, packet.Length);
            while (protocolSI.GetCmdType() != ProtocolSICmdType.ACK ) 
            { 
            networkStream.Read(protocolSI.Buffer,0,protocolSI.Buffer.Length);
            }

        }

        private void CloseCliente()
        {
            byte[] eot = protocolSI.Make(ProtocolSICmdType.EOT);
            networkStream.Write(eot, 0, eot.Length);
            networkStream.Read(protocolSI.Buffer, 0, protocolSI.Buffer.Length);
            networkStream.Close();
            tcpClient.Close();
        }
        private void buttonSair_Click(object sender, EventArgs e)
        {
            CloseCliente();
            this.Close();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            CloseCliente();
        }
    }
}
